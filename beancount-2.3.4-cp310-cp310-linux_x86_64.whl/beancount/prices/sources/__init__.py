"""Implementation of various price extractors.

This package is looked up by the driver script to figure out which extractor to
use.
"""
__copyright__ = "Copyright (C) 2015-2017  Martin Blais"
__license__ = "GNU GPLv2"
