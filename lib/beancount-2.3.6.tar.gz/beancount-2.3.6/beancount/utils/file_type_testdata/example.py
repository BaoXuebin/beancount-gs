#!/usr/bin/env python3
__copyright__ = "Copyright (C) 2016  Martin Blais"
__license__ = "GNU GPLv2"
import platform
print(platform.system())
